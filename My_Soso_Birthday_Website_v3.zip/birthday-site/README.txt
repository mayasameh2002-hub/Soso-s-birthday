Birthday website for My Soso ❤️

HOW TO OPEN:
Double-click index.html.

HOW TO TURN IT INTO A SHAREABLE LINK:
1. Go to Netlify Drop: https://app.netlify.com/drop
2. Drag this entire folder (or the ZIP contents) onto the page.
3. Netlify will instantly give you a public link you can send on WhatsApp.

The site includes the four uploaded photos, a YouTube embed for Bahaa Sultan — Ma3aya, cute animations, captions, and the secret birthday letter. The countdown section has been removed.